#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jun 27 07:09:21 2018

@author: Hoang
"""

# Below partition is using Hoare's algorithm.
def partition(arr, low, high):
  pivot_value = arr[low]
  i = low
  j = high

  print(low)
  print(j)
  print(pivot_value)
  while i < j:
    while i <= high and arr[i] <= pivot_value:
      print('i')
      print(i)
      print(arr[i])
      i += 1
    while arr[j] > pivot_value:
      print('j')
      print(j)
      print(arr[j])
      j -= 1
#    print('j')
#    print(j)
    if i < j:
      print('swap')
      # swap arr[i], arr[j]
      arr[i], arr[j] = arr[j], arr[i]
      print(arr)
      
    print('one while')

  arr[low] = arr[j]
  arr[j] = pivot_value

  # return the pivot index
  print('return')
  print(j)
  return j

def quick_sort_rec(a, l, h):
  if h > l:
    pivot_index = partition(a, l, h)
#    quick_sort_rec(a, l, pivot_index - 1)
#    quick_sort_rec(a, pivot_index + 1, h)

def quick_sort(a):
  quick_sort_rec(a, 0, len(a) - 1)
  
a = [33, 6, 21, 55, 12]
#a = [33, 6, 21, 12, 19, 29, 38, 22, 14, 40]
quick_sort(a)