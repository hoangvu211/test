#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jun 27 00:22:51 2018

@author: Hoang
"""

def reverse_array(arr,start,end):
  while start < end:
    temp = arr[start]
    arr[start] = arr[end]
    arr[end] = temp
    start+=1
    end-=1

def rotate_array_in_place(arr,n):
  length_arr = len(arr)

  # Let's normalize rotations
  # if n > array size or n is negative.
  n = n % length_arr
  if n < 0 :
    # calculate the positive rotations needed.
    n = n + length_arr

  # Let's partition the array based on rotations 'n'.
  # For example: 1, 2, 3, 4, 5 where n = 2.
  # -> 5, 4, 3, 2, 1
  # -> 4, 5, 3, 2, 1
  # -> 4, 5, 1, 2, 3
  reverse_array(arr, 0 , length_arr - 1)
  print(arr)
  reverse_array(arr, 0 , n - 1)
  reverse_array(arr, n, length_arr - 1)
  
  
v1 = [1, 2, 3, 4, 5]
rotate_array_in_place(v1, 2)
for i in xrange(0,len(v1)):
   print(str(v1[i]) + ", ")