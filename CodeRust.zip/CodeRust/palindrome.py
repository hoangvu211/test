#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jul  7 00:40:26 2018

@author: Hoang
"""

def find_palindromes_in_sub_string(s, j, k):
    max_s = -1
    ret_s = ""
    
    if len(s) == 1:
        return s
    while j >= 0 and k < len(s):
        if s[j] == s[k]:
#            max_s = max(max_s, j - k)
            if k - j > max_s:
                max_s = k - j
                ret_s = s[j: (k+1)] 
        else:
            break
        j -= 1
        k += 1
    print(max_s)
    return ret_s
        

def find_palindromes_in_sub_string_loop(s):
  final_max_s = find_palindromes_in_sub_string(s, 0, 0)
  for i in range(0, len(s)):
    print(i)
    odd_pal = find_palindromes_in_sub_string(s, i - 1, i + 1)
    print(odd_pal)
    if len(final_max_s) < len(odd_pal):
        final_max_s = odd_pal
    even_pal = find_palindromes_in_sub_string(s, i, i + 1)
    print(even_pal)
    if len(final_max_s) < len(even_pal):
        final_max_s = even_pal
#    count += find_palindromes_in_sub_string(s, i, i + 1)

  return final_max_s

find_palindromes_in_sub_string('babad', 0, 0)

find_palindromes_in_sub_string('a', 0, 0)

find_palindromes_in_sub_string('abcda', 0, 0)

find_palindromes_in_sub_string_loop('abcda')


find_palindromes_in_sub_string_loop('a')

find_palindromes_in_sub_string_loop('babad')

def addTwoNumbers(l1, l2):
    """
    :type l1: ListNode
    :type l2: ListNode
    :rtype: ListNode
    """
    # len_l = 0
    rest_list = []
    while l1.next != None and l2.next != None:
        rest_list.append(l1.val + l2.val)
        # len_l += 1
        
    sum_res = 0
    for i in range(0, len(rest_list)):
        sum_res += (10**i)*rest_list[i]
        
    return sum_res