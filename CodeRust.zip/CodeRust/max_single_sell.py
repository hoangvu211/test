#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jun 27 01:34:42 2018

@author: Hoang
"""

def find_buy_sell_stock_prices(array):
    
    current_profit = -1000000
    current_buy = array[0]
    global_sell = array[1]
    global_profit = global_sell - current_buy
    
    for i in range(0, len(array)):
        current_profit = array[i] - current_buy
        if current_profit > global_profit:
            global_profit = current_profit
            global_sell = array[i]
        if array[i] <= current_buy:
            current_buy = array[1]
#        if array[i] < global_sell:
#            global_sell = array[i]
            
    print(global_sell)
    print(global_profit)
    result = global_sell - global_profit, global_sell                 

    return result

array = [12, 5, 9, 19]
#array = [ 1, 2, 3, 4, 3, 2, 1, 2, 5 ]  
result = find_buy_sell_stock_prices(array)