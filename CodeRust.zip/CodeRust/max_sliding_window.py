#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jun 26 02:44:55 2018

@author: Hoang
"""

from collections import deque

def find_max_sliding_window(arr, window_size):
    
    window = deque()
    
    for i in range(0, window_size):
        while window and arr[i] > arr[window[-1]]:
            window.pop()
            
        window.append(i)
        
    for i in range(window_size, len(arr)):
        while window and arr[i] >= arr[window[-1]]:
            window.pop()
            
        if window and i - window_size >= window[0]:
            window.popleft()
            
        window.append(i)
        
    return arr[window[0]]

  array = [1,2,3,4,5,6,7,8,9,10]  
  find_max_sliding_window(array, 4)