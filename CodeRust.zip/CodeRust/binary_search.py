#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jun 25 22:08:08 2018

@author: Hoang
"""

def binary_search(a, key):
  mid = int(len(a)/2)
  print(mid)
  print(a)
  print(a[mid])
  if key == a[mid]:
    print('here')
    print(mid)
    return mid
  elif key < a[mid]:
    binary_search(a[:mid], key)
  elif key > a[mid]:
    binary_search(a[mid:], key)
  else:
      return mid
    
def binary_search_rec(a, key, low, high):
  print(low)
  print(high)
  if low > high:
    return -1


  mid = low + ((high - low) // 2)
  print(mid)
  print(a[mid])
  if a[mid] == key:
    return mid
  elif key < a[mid]:
    return binary_search_rec(a, key, low, mid - 1)
  else:
    return binary_search_rec(a, key, mid + 1, high)

def binary_search_sol(a, key):
  return binary_search_rec(a, key, 0, len(a) - 1)


def binary_search_iterative(a, key):
  
  low = 0
  high = len(a) - 1
  
  while low <= high:
    
    mid = low + ((high - low) // 2)
    
    if a[mid] == key:
      return mid
    
    if key < a[mid]:
      high = mid - 1
    else:
      low = mid + 1
  return -1


def binary_search_rot(arr, st, end, key):

  # assuming all the keys are unique.
  
  if st > end:
    return -1

  mid = st + (end-st)/2

  if arr[mid] == key:
    return mid

  if (arr[st] < arr[mid] and
        key < arr[mid] and
        key >= arr[st]):
    return binary_search(arr, st, mid-1, key)
  elif (arr[mid] < arr[end] and 
           key > arr[mid] and
           key <= arr[end]):
    return binary_search(arr, mid+1, end, key)
  elif arr[st] > arr[mid]:
    return binary_search(arr, st, mid-1, key)
  elif arr[end] < arr[mid]:
    return binary_search(arr, mid+1, end, key)

  return -1

def binary_search_rotated(arr, key):
  return binary_search(arr, 0, len(arr)-1, key)


binary_search_sol([1, 10, 20, 47, 59, 63, 99, 100], 21)

binary_search([1, 10, 20, 47, 59, 63], 20)