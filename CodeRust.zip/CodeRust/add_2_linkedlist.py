#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jul  7 10:00:28 2018

@author: Hoang
"""

# Definition for singly-linked list.
 class ListNode(object):
     def __init__(self, x):
         self.val = x
         self.next = None

class Solution(object):
    def addTwoNumbers(self, l1, l2):
        """
        :type l1: ListNode
        :type l2: ListNode
        :rtype: ListNode
        """
        # len_l = 0
        # rest_list = ListNode()
        next_l1 = l1.next
        rest_list = ListNode(0)
        rest_list_temp = rest_list
        while next_l1 != None:
            temp_res = ListNode(l1.val + l2.val)
            rest_list_temp.val = temp_res.val
            rest_list_temp.next = temp_res.next
            next_l1 = next_l1.next
            # len_l += 1
        
        return rest_list