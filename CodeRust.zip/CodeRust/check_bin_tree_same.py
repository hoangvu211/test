#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jul  6 22:23:09 2018

@author: Hoang
"""

def level_order_traversal(root):
  if root == None:
    return
  q = deque()
  q.append(root)

  while q:
    temp = q.popleft()
    print str(temp.data) + ",",
    if temp.left != None:
      q.append(temp.left)
    if temp.right != None:
      q.append(temp.right)

  print

def are_identical(root1, root2):
  if root1 == None and root2 == None:
    return True
  
  if root1 != None and root2 != None:
    return (root1.data == root2.data and
              are_identical(root1.left, root2.left) and
              are_identical(root1.right, root2.right))
  
  return False

arr1 = [100,50,200,25,125,350]
arr2 = [1,2,10,50,180,199]
root1 = create_BST(arr1)
print "\nLevel Order Traversal Tree1:",
level_order_traversal(root1)
root2 = create_BST(arr2)
print "\nLevel Order Traversal Tree2:",
level_order_traversal(root2)
print are_identical(root1, root1)
print are_identical(root1, None)
print are_identical(None, None)
print are_identical(root1, root2)

nums = [2, 7, 11, 15]
target = 9
def twoSum(nums, target):
    dict_nums = {}
    for idx, num in enumerate(nums):
        print(idx)
        if target - num in dict_nums:
            return [dict_nums[target - num], idx]
        else:
            dict_nums[num] = idx
        print(dict_nums)
            
twoSum(nums, target)