#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jul  7 00:08:44 2018

@author: Hoang
"""

def find_max_sliding_window(arr, window_size):
  if window_size > len(arr):
    return

  window = deque()

  #find out max for first window
  for i in xrange(0, window_size):
    while window and arr[i] >= arr[window[-1]]:
      window.pop()
    window.append(i)

  print arr[window[0]]
  
  for i in xrange(window_size, len(arr)):
    #remove all numbers that are smaller than current number
    #from the tail of list
    while window and arr[i] >= arr[window[-1]]:
      window.pop()

    #remove first number if it doesn't fall in the window anymore
    if window and (window[0] <= i - window_size) :
      window.popleft()

    window.append(i)
    print arr[window[0]]
    
    

def length_of_longest_substring(s):
    set_s = set()
    n = len(s)
    i = 0
    j = 0
    ans = 0
    while i < n and j < n:
        if s[j] not in set_s:
            set_s.add(s[j])
            j += 1
            ans = max(ans, j-i)
        else:
            print(set_s)
            set_s.remove(s[i])
            i += 1
    return ans
    
length_of_longest_substring("abcabcbb")
