#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jul  7 17:20:46 2018

@author: Hoang
"""

import copy
# >>> c = copy.deepcopy(a)

class Colours:
    # code assumes that both dimensions of grid are same
    def __init__(self, grid, dictionary, x_dim=3, y_dim=4):
        self.grid = grid
        self.x_dim = x_dim
        self.y_dim = y_dim
        self.dictionary = dictionary
        self.biggest_map = {}
        self.biggest_current = ""
        self.longest_len = 0
        self.state = [[False for y in range(y_dim)] \
                      for x in range(x_dim)]

    def find_all_nbrs(self, x, y):
        nbrs = []

        try:
            if x != 0 and self.state[x-1][y] == False:
                nbrs.append([x-1, y])

            if x < (self.x_dim-1)  and self.state[x+1][y] == False:
                nbrs.append([x+1, y])

            if y < (self.y_dim-1) and self.state[x][y+1] == False:
                nbrs.append([x, y+1])

            if y != 0 and self.state[x][y-1] == False:
                nbrs.append([x, y-1])
        except IndexError:
            print(x)
            print(y)

        # left and right of i, j
        # for i in range(max(0, x - 1), min(x + 2, len(self.grid))):
        #     # up and down of i, j
        #     for j in range(max(0, y - 1), min(y + 2, len(self.grid))):
        #         if i == x and j == y:
        #             continue
        #         # if i > x and j > y:
        #         #     continue
        #         # if i < x and j < y
        #         if self.state[i][j] == False:
        #             nbrs.append([i, j])
        return nbrs

    def find_all_colours(self):
        words = set([])
        for i in range(0, len(self.grid)):
            for j in range(0, len(self.grid)):
                current_word = ""
                self.find_colours_rec(i, j, current_word, words)
        return words

    def find_colours_rec(self, i, j, current, words):
        legal = True
        if len(current) > 0:
            for c in current[1:]:
                if c != current[0]:
                    legal = False
                    break

        if not legal:
            return
        else:
            if self.longest_len < len(current):
                self.longest_len = len(current)
                self.biggest_map = copy.deepcopy(self.state)
                self.biggest_current = current
            words.add(current)
            # self.dictionary[current] = current
        # if len(current) > 0 and (current in self.dictionary):
        #     words.add(current)

        # we can really speed up our algorithm if we have prefix method available
        # for our dictionary by using code like below

        # if not dictionary.is_prefix(current):
        #  // if current word is not prefix of any word in dictionary
        #  // we don't need to continue with search
        #  return

        nbrs = self.find_all_nbrs(i, j)
        for pr in nbrs:
            first = pr[0]
            second = pr[1]
            current += self.grid[first][second]
            self.state[first][second] = True
            self.find_colours_rec(first, second, current, words)
            current = current[:-1]  # equivalent to current = current[0:len(current) - 1]
            self.state[first][second] = False

grid = [
    ['1', '1', '0', '2'],
    ['1', '0', '2', '0'],
    ['2', '0', '0', '0']
      ]

c = Colours(grid, dictionary=None)
colors = c.find_all_colours()
print(colors)
# colours = find_all_colors()